package listener;

import floje.u3u4.Product;


//Das DeleteListener interface zum l�schen
public interface DeleteListener {
	public void deletePerfomed(Product[] product);
}
