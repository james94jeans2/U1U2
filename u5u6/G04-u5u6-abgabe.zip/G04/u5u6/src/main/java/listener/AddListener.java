package listener;

import floje.Product;

//Das AddListener interface zum Hinzuf�gen
public interface AddListener {
	public void addPerfomed(Product product);
}
