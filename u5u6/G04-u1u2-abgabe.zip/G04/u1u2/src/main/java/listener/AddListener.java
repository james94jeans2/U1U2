package listener;

import floje.u1u2.Product;

//Das AddListener interface zum Hinzuf�gen
public interface AddListener {
	public void addPerfomed(Product product);
}
