package listener;

import floje.u1u2.Product;


//Das DeleteListener interface zum l�schen
public interface DeleteListener {
	public void deletePerfomed(Product[] product);
}
