package listener;

import floje.u3u4.Product;

//Das AddListener interface zum Hinzuf�gen
public interface AddListener {
	public void addPerfomed(Product product);
}
